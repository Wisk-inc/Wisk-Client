#!/usr/bin/env python3
"""
Jumbo AI Colab Demo Script
Run this in Google Colab to get started with Jumbo AI
"""

def run_colab_demo():
    """Run the Jumbo AI demo in Google Colab"""
    print("🤖 Jumbo AI - Google Colab Demo")
    print("=" * 50)
    
    # Install requirements
    import subprocess
    import sys
    
    print("📦 Installing requirements...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements_web_demo.txt"], check=True)
        print("✅ Requirements installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing requirements: {e}")
        return
    
    # Import libraries
    print("\n📚 Importing libraries...")
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch
        print("✅ Libraries imported successfully!")
    except ImportError as e:
        print(f"❌ Error importing libraries: {e}")
        return
    
    # Load model
    print("\n🔄 Loading Jumbo AI model...")
    try:
        # Use a smaller model for Colab compatibility
        model_name = "microsoft/DialoGPT-medium"
        tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
        ).eval()
        print("✅ Jumbo AI model loaded successfully!")
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return
    
    # Welcome message
    print("\n" + "=" * 60)
    print("🎉 WELCOME TO JUMBO AI! 🎉")
    print("=" * 60)
    print("\n🤖 Hello! My name is Jumbo, and I'm your AI assistant.")
    print("💬 I'm here to help you with any questions or tasks you have.")
    print("🚀 I can help with coding, writing, problem-solving, and much more!")
    print("\n📝 You can chat with me using the chat_with_jumbo() function.")
    print("=" * 60)
    
    # Chat function
    def chat_with_jumbo(message, max_length=150):
        """Chat with Jumbo AI"""
        input_text = f"Human: {message}\nJumbo: I'm Jumbo, your helpful AI assistant. "
        
        inputs = tokenizer.encode(input_text, return_tensors='pt')
        
        with torch.no_grad():
            outputs = model.generate(
                inputs,
                max_length=inputs.shape[1] + max_length,
                num_return_sequences=1,
                temperature=0.7,
                do_sample=True,
                pad_token_id=tokenizer.eos_token_id
            )
        
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        if "Jumbo:" in response:
            jumbo_response = response.split("Jumbo:")[-1].strip()
            return jumbo_response
        else:
            return response
    
    # Example conversation
    print("\n🗣️  Example conversation:")
    print("-" * 40)
    
    test_message = "Hello! Can you tell me about yourself?"
    print(f"Human: {test_message}")
    
    response = chat_with_jumbo(test_message)
    print(f"Jumbo: {response}")
    
    print("\n" + "-" * 40)
    print("✅ Jumbo AI is ready to chat!")
    print("\n💡 Usage Tips:")
    print("1. Use chat_with_jumbo('your message') to chat")
    print("2. Try questions like:")
    print("   - 'Help me write a Python function'")
    print("   - 'Explain quantum computing'")
    print("   - 'Write a creative story'")
    print("   - 'Solve this math problem: 2x + 5 = 13'")
    print("\n🚀 For more features, run:")
    print("- python cli_demo.py (Command line interface)")
    print("- python web_demo.py (Web interface)")
    print("- python openai_api.py (API server)")
    print("\n🎯 Remember: Jumbo knows its name is Jumbo!")
    print("\nEnjoy chatting with Jumbo AI! 🤖✨")
    
    return chat_with_jumbo

if __name__ == "__main__":
    chat_function = run_colab_demo()
    
    # Interactive demo
    if chat_function:
        print("\n" + "=" * 50)
        print("🎮 Interactive Demo")
        print("=" * 50)
        
        while True:
            try:
                user_input = input("\nYou: ")
                if user_input.lower() in ['quit', 'exit', 'bye']:
                    print("Jumbo: Goodbye! It was great chatting with you! 🤖✨")
                    break
                
                response = chat_function(user_input)
                print(f"Jumbo: {response}")
            except KeyboardInterrupt:
                print("\n\nJumbo: Goodbye! It was great chatting with you! 🤖✨")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
                break