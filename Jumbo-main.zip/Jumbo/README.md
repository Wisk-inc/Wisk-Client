# 🤖 Jumbo AI

<p align="center">
    <img src="https://via.placeholder.com/400x100/4A90E2/FFFFFF?text=JUMBO+AI" width="400"/>
</p>

<p align="center">
    <strong>Your Friendly AI Assistant</strong>
</p>

<p align="center">
    🤖 <a href="#quick-start">Quick Start</a>&nbsp&nbsp | &nbsp&nbsp🚀 <a href="#google-colab">Google Colab</a>&nbsp&nbsp | &nbsp&nbsp 📱 <a href="#web-demo">Web Demo</a> &nbsp&nbsp ｜ &nbsp&nbsp💬 <a href="#chat">Chat</a>
</p>

<br>

> [!Important]
> Welcome to Jumbo AI! This is a simplified, user-friendly version designed for easy installation and use in Google Colab and other environments. Jumbo knows its name is Jumbo and is here to help you!

<br>

## 🎯 What is Jumbo AI?

Jumbo AI is a powerful, friendly language model that can help you with:

- 💬 **Natural conversations** - Chat with Jumbo about anything!
- 💻 **Code generation** - Get help with programming and debugging
- ✍️ **Creative writing** - Stories, poems, and creative content
- 🧠 **Problem solving** - Math, logic, and analytical tasks
- 📚 **Learning** - Explanations and educational content
- 🚀 **And much more!**

## 🚀 Quick Start

### Option 1: Google Colab (Recommended)

1. **Upload this repository to Google Colab**
2. **Run the installation:**
   ```python
   !python install_jumbo.py
   ```
3. **Start chatting:**
   ```python
   !python colab_demo.py
   ```

### Option 2: Local Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-username/Jumbo.git
   cd Jumbo
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements_web_demo.txt
   ```

3. **Run the demo:**
   ```bash
   python colab_demo.py
   ```

## 📱 Google Colab

For the best experience, use our Google Colab notebook:

1. Open `Jumbo_Colab_Demo.ipynb` in Google Colab
2. Run all cells to install and start using Jumbo AI
3. Chat with Jumbo using the interactive interface

## 💬 Chat with Jumbo

### Command Line Interface
```bash
python cli_demo.py
```

### Web Interface
```bash
python web_demo.py
```

### API Server
```bash
python openai_api.py
```

## 🎮 Example Usage

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

# Load Jumbo model
tokenizer = AutoTokenizer.from_pretrained('Jumbo/Jumbo-7B-Chat', trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained('Jumbo/Jumbo-7B-Chat', device_map='auto', trust_remote_code=True).eval()

# Chat with Jumbo
response, history = model.chat(tokenizer, "Hello! My name is Jumbo. How can I help you?", history=None)
print(response)
```

## 🛠️ Requirements

- Python 3.8+
- PyTorch 1.12+
- Transformers 4.32+
- CUDA 11.4+ (for GPU users)

## 📦 Installation

```bash
pip install -r requirements.txt
pip install -r requirements_web_demo.txt
```

## 🎯 Features

- **Easy Installation** - Simple setup process
- **Google Colab Ready** - Works perfectly in Colab
- **Multiple Interfaces** - CLI, Web, and API
- **Friendly Personality** - Jumbo knows its name and is helpful
- **Lightweight** - Optimized for easy deployment

## 🤖 Meet Jumbo

Jumbo is your friendly AI assistant who:
- Knows its name is Jumbo
- Is always ready to help
- Loves to chat and learn
- Can help with coding, writing, and problem-solving
- Is designed to be approachable and helpful

## 🚀 Getting Started

1. **Install Jumbo AI** using the installation script
2. **Run the demo** to see Jumbo in action
3. **Start chatting** with your new AI friend!

## 📞 Support

If you have any questions or need help:
- Check the FAQ section
- Open an issue on GitHub
- Contact us for support

## 🎉 Welcome Message

When you first run Jumbo AI, you'll see:

```
🎉 WELCOME TO JUMBO AI! 🎉
============================================================

🤖 Hello! My name is Jumbo, and I'm your AI assistant.
💬 I'm here to help you with any questions or tasks you have.
🚀 I can help with coding, writing, problem-solving, and much more!

📝 You can chat with me using the chat_with_jumbo() function.
============================================================
```

## 📄 License

This project is licensed under the Apache 2.0 License - see the [LICENSE](LICENSE) file for details.

---

**Enjoy chatting with Jumbo AI! 🤖✨**

<p align="center">
    Made with ❤️ for the AI community
</p>