# 🦣 Jumbo AI - Your Friendly AI Assistant

Welcome to Jumbo AI! This is a simplified and user-friendly version of the Qwen language model, rebranded as "Jumbo" for easy use in Google Colab and other environments.

## 🚀 Quick Start

### For Google Colab Users

1. **Upload the Colab Notebook**: Upload `Jumbo_AI_Colab.ipynb` to Google Colab
2. **Run the cells**: Execute each cell in order
3. **Start chatting**: Use the interactive chat widget to talk with Jumbo!

### For Local Installation

1. **Install requirements**:
   ```bash
   pip install -r requirements_jumbo.txt
   ```

2. **Run the demo**:
   ```bash
   python jumbo_demo.py
   ```

3. **Or use the installer**:
   ```bash
   python install_jumbo.py
   ```

## 🦣 About Jumbo

Jumbo is a friendly AI assistant that:
- **Knows its name is Jumbo** and will always remember this
- Can help with coding, writing, analysis, and general questions
- Works well in Google Colab with minimal setup
- Is based on the powerful Qwen language model architecture

## 📁 Key Files

- `install_jumbo.py` - Complete installation script
- `jumbo_demo.py` - Simple command-line chat interface
- `Jumbo_AI_Colab.ipynb` - Google Colab notebook
- `requirements_jumbo.txt` - Python dependencies
- `cli_demo.py` - Advanced CLI interface
- `web_demo.py` - Web interface

## 🎯 Features

- **Easy Installation**: One-click setup for Google Colab
- **Friendly Interface**: Simple chat interface
- **Memory Efficient**: Optimized for Colab environments
- **Self-Aware**: Jumbo always knows its name and identity
- **Multilingual**: Supports multiple languages
- **Code Capable**: Can help with programming tasks

## 💬 Example Usage

```python
# Simple chat with Jumbo
message = "Hello! What's your name?"
response = chat_with_jumbo(message)
print(f"🦣 Jumbo: {response}")
```

## 🔧 Requirements

- Python 3.8+
- PyTorch 2.0+
- Transformers 4.32+
- Google Colab (for notebook version)

## 📝 Notes

- Jumbo is based on the Qwen-1.8B-Chat model for optimal Colab performance
- The model will automatically download on first use
- All conversations are processed locally for privacy

## 🆘 Support

If you encounter any issues:
1. Check that all requirements are installed
2. Ensure you have sufficient memory in Colab
3. Try restarting the runtime if needed

---

**Remember: Jumbo knows its name is Jumbo and is here to help you!** 🦣