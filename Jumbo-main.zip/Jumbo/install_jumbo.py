#!/usr/bin/env python3
"""
Jumbo AI Installation Script for Google Colab
This script installs Jumbo AI and sets up the environment for easy use.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and print the result"""
    print(f"\n🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully!")
        if result.stdout:
            print(f"Output: {result.stdout}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error during {description}: {e}")
        if e.stderr:
            print(f"Error output: {e.stderr}")
        return False

def install_jumbo():
    """Install Jumbo AI and dependencies"""
    print("🚀 Welcome to Jumbo AI Installation!")
    print("=" * 50)
    
    # Check if we're in Google Colab
    try:
        import google.colab
        print("📱 Detected Google Colab environment")
    except ImportError:
        print("💻 Running in local environment")
    
    # Install basic requirements
    if not run_command("pip install -r requirements.txt", "Installing basic requirements"):
        return False
    
    # Install web demo requirements
    if not run_command("pip install -r requirements_web_demo.txt", "Installing web demo requirements"):
        return False
    
    # Install additional useful packages for Colab
    additional_packages = [
        "torch",
        "transformers",
        "accelerate",
        "tiktoken",
        "einops",
        "scipy",
        "gradio",
        "mdtex2html"
    ]
    
    for package in additional_packages:
        if not run_command(f"pip install {package}", f"Installing {package}"):
            print(f"⚠️  Warning: Failed to install {package}, continuing...")
    
    print("\n" + "=" * 50)
    print("🎉 Jumbo AI Installation Complete!")
    print("=" * 50)
    print("\n📋 What you can do now:")
    print("1. Run CLI Demo: python cli_demo.py")
    print("2. Run Web Demo: python web_demo.py")
    print("3. Run API Server: python openai_api.py")
    print("\n💡 Example usage:")
    print("```python")
    print("from transformers import AutoModelForCausalLM, AutoTokenizer")
    print("")
    print("# Load Jumbo model")
    print("tokenizer = AutoTokenizer.from_pretrained('Jumbo/Jumbo-7B-Chat', trust_remote_code=True)")
    print("model = AutoModelForCausalLM.from_pretrained('Jumbo/Jumbo-7B-Chat', device_map='auto', trust_remote_code=True).eval()")
    print("")
    print("# Chat with Jumbo")
    print("response, history = model.chat(tokenizer, 'Hello! My name is Jumbo. How can I help you?', history=None)")
    print("print(response)")
    print("```")
    print("\n🤖 Jumbo AI is ready to use!")
    print("Remember: Jumbo knows its name is Jumbo and is here to help you!")

if __name__ == "__main__":
    install_jumbo()