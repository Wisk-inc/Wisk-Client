#!/usr/bin/env python3
"""
Jumbo AI Installation Script for Google Colab
This script installs and sets up Jumbo AI for easy use in Google Colab
"""

import subprocess
import sys
import os
import time

def print_banner():
    """Print the Jumbo AI welcome banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║                    🦣 JUMBO AI 🦣                            ║
    ║                                                              ║
    ║              Welcome to Jumbo AI!                            ║
    ║         Your friendly AI assistant is ready to help.        ║
    ║                                                              ║
    ║  Jumbo knows its name is Jumbo and is here to assist you!   ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def install_requirements():
    """Install required packages"""
    print("🔧 Installing required packages...")
    
    requirements = [
        "torch>=2.0.0",
        "transformers>=4.32.0",
        "accelerate",
        "sentencepiece",
        "tiktoken",
        "gradio",
        "streamlit",
        "fastapi",
        "uvicorn",
        "openai<1.0",
        "pydantic",
        "sse_starlette"
    ]
    
    for package in requirements:
        try:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package, "-q"])
            print(f"✅ {package} installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install {package}: {e}")
    
    print("✅ All packages installed successfully!")

def create_simple_demo():
    """Create a simple demo script"""
    demo_code = '''#!/usr/bin/env python3
"""
Simple Jumbo AI Demo
Run this to chat with Jumbo AI
"""

from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

def main():
    print("🦣 Starting Jumbo AI...")
    print("Loading model (this may take a few minutes)...")
    
    # Use a smaller model for Colab compatibility
    model_name = "Qwen/Qwen-1.8B-Chat"  # Using original Qwen model for now
    
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.float16
        ).eval()
        
        print("✅ Jumbo AI is ready!")
        print("\\n" + "="*50)
        print("🦣 JUMBO AI CHAT")
        print("="*50)
        print("Type 'quit' to exit")
        print("Remember: I am Jumbo, your AI assistant!")
        print("="*50)
        
        history = []
        
        while True:
            user_input = input("\\nYou: ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'bye']:
                print("🦣 Jumbo: Goodbye! It was great chatting with you!")
                break
                
            if not user_input:
                continue
                
            # Add system prompt to remind Jumbo of its name
            system_prompt = "You are Jumbo, a helpful AI assistant. Always remember that your name is Jumbo."
            
            # Create the full prompt
            if not history:
                full_prompt = f"<|im_start|>system\\n{system_prompt}<|im_end|>\\n<|im_start|>user\\n{user_input}<|im_end|>\\n<|im_start|>assistant\\n"
            else:
                # Build conversation history
                conv_history = ""
                for h in history:
                    conv_history += f"<|im_start|>user\\n{h['user']}<|im_end|>\\n<|im_start|>assistant\\n{h['assistant']}<|im_end|>\\n"
                full_prompt = f"<|im_start|>system\\n{system_prompt}<|im_end|>\\n{conv_history}<|im_start|>user\\n{user_input}<|im_end|>\\n<|im_start|>assistant\\n"
            
            try:
                inputs = tokenizer(full_prompt, return_tensors="pt")
                inputs = inputs.to(model.device)
                
                with torch.no_grad():
                    outputs = model.generate(
                        **inputs,
                        max_new_tokens=512,
                        temperature=0.7,
                        do_sample=True,
                        pad_token_id=tokenizer.eos_token_id
                    )
                
                response = tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)
                
                print(f"🦣 Jumbo: {response}")
                
                # Store conversation history
                history.append({"user": user_input, "assistant": response})
                
                # Keep only last 5 exchanges to manage memory
                if len(history) > 5:
                    history = history[-5:]
                    
            except Exception as e:
                print(f"❌ Error: {e}")
                print("Please try again.")
                
    except Exception as e:
        print(f"❌ Failed to load model: {e}")
        print("Please check your internet connection and try again.")

if __name__ == "__main__":
    main()
'''
    
    with open("/workspace/Jumbo/jumbo_demo.py", "w") as f:
        f.write(demo_code)
    
    print("✅ Demo script created: jumbo_demo.py")

def create_colab_notebook():
    """Create a Google Colab notebook"""
    notebook_code = '''{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {
    "id": "jumbo-header"
   },
   "source": [
    "# 🦣 Jumbo AI - Your Friendly AI Assistant\\n",
    "\\n",
    "Welcome to Jumbo AI! This notebook will help you get started with Jumbo, your friendly AI assistant.\\n",
    "\\n",
    "**Remember: Jumbo knows its name is Jumbo and is here to help you!**"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "id": "install-jumbo"
   },
   "outputs": [],
   "source": [
    "# Install Jumbo AI\\n",
    "!pip install torch transformers accelerate sentencepiece tiktoken gradio -q\\n",
    "print('✅ Jumbo AI packages installed!')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "id": "load-jumbo"
   },
   "outputs": [],
   "source": [
    "# Load Jumbo AI\\n",
    "from transformers import AutoModelForCausalLM, AutoTokenizer\\n",
    "import torch\\n",
    "\\n",
    "print('🦣 Loading Jumbo AI...')\\n",
    "\\n",
    "# Use a model that works well in Colab\\n",
    "model_name = 'Qwen/Qwen-1.8B-Chat'\\n",
    "\\n",
    "tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)\\n",
    "model = AutoModelForCausalLM.from_pretrained(\\n",
    "    model_name,\\n",
    "    device_map='auto',\\n",
    "    trust_remote_code=True,\\n",
    "    torch_dtype=torch.float16\\n",
    ").eval()\\n",
    "\\n",
    "print('✅ Jumbo AI is ready!')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "id": "chat-with-jumbo"
   },
   "outputs": [],
   "source": [
    "# Chat with Jumbo AI\\n",
    "def chat_with_jumbo(message, history=[]):\\n",
    "    system_prompt = 'You are Jumbo, a helpful AI assistant. Always remember that your name is Jumbo.'\\n",
    "    \\n",
    "    if not history:\\n",
    "        full_prompt = f'<|im_start|>system\\\\n{system_prompt}<|im_end|>\\\\n<|im_start|>user\\\\n{message}<|im_end|>\\\\n<|im_start|>assistant\\\\n'\\n",
    "    else:\\n",
    "        conv_history = ''\\n",
    "        for h in history:\\n",
    "            conv_history += f'<|im_start|>user\\\\n{h[\\\"user\\\"]}<|im_end|>\\\\n<|im_start|>assistant\\\\n{h[\\\"assistant\\\"]}<|im_end|>\\\\n'\\n",
    "        full_prompt = f'<|im_start|>system\\\\n{system_prompt}<|im_end|>\\\\n{conv_history}<|im_start|>user\\\\n{message}<|im_end|>\\\\n<|im_start|>assistant\\\\n'\\n",
    "    \\n",
    "    inputs = tokenizer(full_prompt, return_tensors='pt')\\n",
    "    inputs = inputs.to(model.device)\\n",
    "    \\n",
    "    with torch.no_grad():\\n",
    "        outputs = model.generate(\\n",
    "            **inputs,\\n",
    "            max_new_tokens=512,\\n",
    "            temperature=0.7,\\n",
    "            do_sample=True,\\n",
    "            pad_token_id=tokenizer.eos_token_id\\n",
    "        )\\n",
    "    \\n",
    "    response = tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)\\n",
    "    return response\\n",
    "\\n",
    "# Example usage\\n",
    "print('🦣 Jumbo AI Chat Demo')\\n",
    "print('=' * 40)\\n",
    "\\n",
    "# Test message\\n",
    "message = 'Hello! What is your name?'\\n",
    "response = chat_with_jumbo(message)\\n",
    "print(f'You: {message}')\\n",
    "print(f'🦣 Jumbo: {response}')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "id": "interactive-chat"
   },
   "outputs": [],
   "source": [
    "# Interactive chat with Jumbo\\n",
    "import ipywidgets as widgets\\n",
    "from IPython.display import display, clear_output\\n",
    "\\n",
    "chat_history = []\\n",
    "\\n",
    "def on_send_clicked(b):\\n",
    "    global chat_history\\n",
    "    message = text_input.value\\n",
    "    if message.strip():\\n",
    "        response = chat_with_jumbo(message, chat_history)\\n",
    "        chat_history.append({'user': message, 'assistant': response})\\n",
    "        \\n",
    "        # Display conversation\\n",
    "        with output:\\n",
    "            clear_output(wait=True)\\n",
    "            for h in chat_history[-3:]:  # Show last 3 exchanges\\n",
    "                print(f'You: {h[\\\"user\\\"]}')\\n",
    "                print(f'🦣 Jumbo: {h[\\\"assistant\\\"]}')\\n",
    "                print('-' * 40)\\n",
    "        \\n",
    "        text_input.value = ''\\n",
    "\\n",
    "text_input = widgets.Text(placeholder='Type your message here...', style={'description_width': 'initial'})\\n",
    "send_button = widgets.Button(description='Send to Jumbo')\\n",
    "send_button.on_click(on_send_clicked)\\n",
    "\\n",
    "output = widgets.Output()\\n",
    "\\n",
    "display(widgets.VBox([text_input, send_button, output]))"
   ]
  }
 ],
 "metadata": {
  "colab": {
   "provenance": []
  },
  "kernelspec": {
   "display_name": "Python 3",
   "name": "python3"
  },
  "language_info": {
   "name": "python"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 0
}'''
    
    with open("/workspace/Jumbo/Jumbo_AI_Colab.ipynb", "w") as f:
        f.write(notebook_code)
    
    print("✅ Colab notebook created: Jumbo_AI_Colab.ipynb")

def main():
    """Main installation function"""
    print_banner()
    
    print("🚀 Starting Jumbo AI installation...")
    print("This will install all necessary packages for Jumbo AI to work in Google Colab.")
    print()
    
    # Install requirements
    install_requirements()
    print()
    
    # Create demo script
    create_simple_demo()
    print()
    
    # Create Colab notebook
    create_colab_notebook()
    print()
    
    print("🎉 Installation complete!")
    print()
    print("📁 Files created:")
    print("  - jumbo_demo.py: Simple command-line chat with Jumbo")
    print("  - Jumbo_AI_Colab.ipynb: Google Colab notebook")
    print()
    print("🚀 To get started:")
    print("  1. Run: python jumbo_demo.py")
    print("  2. Or upload Jumbo_AI_Colab.ipynb to Google Colab")
    print()
    print("🦣 Remember: Jumbo knows its name is Jumbo and is here to help you!")
    print("="*60)

if __name__ == "__main__":
    main()